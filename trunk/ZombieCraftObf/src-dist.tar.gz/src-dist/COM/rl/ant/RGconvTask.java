/* ===========================================================================
 * $RCSfile: RGconvTask.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import COM.rl.obf.*;


/**
 * RGconv task for Apache Ant build tool.
 *
 * @author      Mark Welsh
 */
public class RGconvTask extends Task
{
    // Constants -------------------------------------------------------------


    // Fields ----------------------------------------------------------------
    private String rgsFile;
    private String inListFile;
    private String outListFile;


    // Class Methods ---------------------------------------------------------


    // Instance Methods ------------------------------------------------------
    /** Set the script file name. */
    public void setRgsfile(String rgsFile) 
    {
        this.rgsFile = rgsFile;
    }

    /** Set the input file of unobfuscated identifiers. */
    public void setInlistfile(String inListFile) 
    {
        this.inListFile = inListFile;
    }

    /** Set the output file for obfuscated identifiers. */
    public void setOutlistfile(String outListFile) 
    {
        this.outListFile = outListFile;
    }

    /** Execute the task. */
    public void execute() throws BuildException 
    {
        if (rgsFile == null || inListFile == null || outListFile == null)
        {
            throw new BuildException("RGconvTask requires rgsfile, inlistfile, and outlistfile to be set.");
        }
        try 
        {
            RGconvImpl.convert(rgsFile, inListFile, outListFile);
        }
        catch (Exception e)
        {
            throw new BuildException(e);
        }
    }
}
