/* ===========================================================================
 * $RCSfile: TreeEntry.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.util;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * An entry in the tree control list.
 *
 * @author      Mark Welsh
 */
public interface TreeEntry
{
    // Interface Methods -----------------------------------------------------
    /** Can the element be opened. */
    public boolean canOpen();
    /** Is the element open in the tree? */
    public boolean isOpen();
    /** Set if the element is open in the tree. */
    public void setOpen(boolean isOpen);
    /** String representation of the element for the List. */
    public String toString();
    /** Number of children. */
    public int childCount();
    /** Return the children TreeEntry's. */
    public Enumeration elements();
}
