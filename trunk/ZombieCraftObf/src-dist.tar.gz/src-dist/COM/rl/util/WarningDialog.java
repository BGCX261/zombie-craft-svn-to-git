/* ===========================================================================
 * $RCSfile: WarningDialog.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.util;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Warning dialog box.
 *
 * @author      Mark Welsh
 */
public class WarningDialog extends Dialog
{
    public WarningDialog(Frame f, String title, String[] phrases)
    {
        this(f, title, phrases, false);
    }

    public WarningDialog(Frame f, String title, String[] phrases, boolean useTextArea)
    {
        super(f, title, false);

        // Warning text
        if (useTextArea)
        {
            TextArea ta = new TextArea(10, 75);
            //ta.setBackground(Color.lightGray);
            ta.setEditable(false);
            ta.setFont(new Font("Helvetica", Font.PLAIN, 12));
            for (int i = 0; i < phrases.length; i++)
            {
                ta.append(phrases[i]);
                ta.append("\n");
            }
            add("Center", ta);
        }
        else
        {
            Panel left = new Panel() {public Insets getInsets() {return new Insets(4, 4, 4, 4);}};
            left.setLayout(new GridLayout(0, 1));
            left.setFont(new Font("Helvetica", Font.PLAIN, 12));
            for (int i = 0; i < phrases.length; i++)
            {
                left.add(new Label(phrases[i]));
            }
            add("Center", left);
        }

        // Okay button
        Button okay = new Button("  Okay  ");
        Panel right = new Panel();
        right.setLayout(new FlowLayout(FlowLayout.CENTER));
        right.add(okay);
        add("East", right);

        // Set closing event handlers and pack to preferred size
        addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent e) {setVisible(false);}});
        okay.addActionListener(new ActionListener() {public void actionPerformed(ActionEvent e) {setVisible(false);}});
        pack();

        // Position the dialog centrally in its parent
        Rectangle bounds = f.getBounds();
        Rectangle myBounds = getBounds();
        setLocation(bounds.x + (bounds.width - myBounds.width) / 2, bounds.y + (bounds.height - myBounds.height) / 2);
        setVisible(true);
        getToolkit().beep();
    }
}

