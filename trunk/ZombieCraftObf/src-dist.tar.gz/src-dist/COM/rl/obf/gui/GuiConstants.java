/* ===========================================================================
 * $RCSfile: GuiConstants.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf.gui;

/**
 * Constants for the rgs script GUI.
 *
 * @author      Mark Welsh
 */
public interface GuiConstants
{
    // Constants -------------------------------------------------------------
    public static final String CLASS_EXT = ".class";
    public static final String CLASS_NAME_APPLET = "java/applet/Applet";
    public static final String METHOD_NAME_MAIN = "main";
    public static final String METHOD_DESCRIPTOR_MAIN = "([Ljava/lang/String;)V";
    public static final String SCRIPT_CLASS = ".class ";
    public static final String SCRIPT_PROTECTED = " protected";
    public static final String SCRIPT_PUBLIC = " public";
    public static final String SCRIPT_METHODS_ONLY = " method ";
    public static final String SCRIPT_FIELDS_ONLY = " field ";
    public static final String SCRIPT_METHOD = ".method ";
    public static final String SCRIPT_FIELD = ".field ";
    public static final String SCRIPT_ATTR = ".attribute ";
    public static final String SCRIPT_SF = "SourceFile";
    public static final String SCRIPT_LVT = "LocalVariableTable";
    public static final String SCRIPT_LNT = "LineNumberTable";
}
