/* ===========================================================================
 * $RCSfile: ClPreserve.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf.gui;

import java.io.*;
import java.util.*;
import COM.rl.obf.*;

/**
 * Data structure for class preservations.
 *
 * @author      Mark Welsh
 */
public class ClPreserve extends TreeItemPreserve
{
    private PkCl pkcl;
    private boolean isKeepPublic;
    private boolean isKeepProtected;
    private boolean isKeepMethodsAndFields;
    private boolean isKeepMethodsOnly;
    private boolean isKeepFieldsOnly;

    public PkCl getPkCl() {return pkcl;}

    public boolean isKeepPublic() {return isKeepPublic;}

    public boolean isKeepProtected() {return isKeepProtected;}

    public boolean isKeepMethodsAndFields() {return isKeepMethodsAndFields;}

    public boolean isKeepMethodsOnly() {return isKeepMethodsOnly;}

    public boolean isKeepFieldsOnly() {return isKeepFieldsOnly;}

    public void setPreserve(boolean isPreserve)
    {
        this.isPreserve = isPreserve;
        if (!isPreserve)
        {
            setKeepPublic(false);
        }
    }

    public void setKeepPublic(boolean isKeepPublic)
    {
        this.isKeepPublic = isKeepPublic;
        if (!isKeepPublic)
        {
            setKeepProtected(false);
            keepMethodsAndFields();
        }
    }

    public void setKeepProtected(boolean isKeepProtected) {this.isKeepProtected = isKeepProtected;}

    public void keepMethodsAndFields()
    {
        isKeepMethodsAndFields = true;
        isKeepMethodsOnly = false;
        isKeepFieldsOnly = false;
    }

    public void keepMethodsOnly()
    {
        isKeepMethodsAndFields = false;
        isKeepMethodsOnly = true;
        isKeepFieldsOnly = false;
    }

    public void keepFieldsOnly()
    {
        isKeepMethodsAndFields = false;
        isKeepMethodsOnly = false;
        isKeepFieldsOnly = true;
    }

    public ClPreserve(PkCl pkcl)
    {
        this.pkcl = pkcl;
    }
}
