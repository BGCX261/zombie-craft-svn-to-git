/* ===========================================================================
 * $RCSfile: OverloadNameMaker.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf;

import java.io.*;
import java.util.*;
import COM.rl.util.*;

/**
 * Name generator that uses (almost) the full Java identifier namespace,
 * and uses maximal overloading of names based on arg-list of methods.
 *
 * @author      Mark Welsh
 */
public class OverloadNameMaker extends NameMaker
{
    // Fields ----------------------------------------------------------------
    private String[] firstLetter = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l",
                                    "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
                                    "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                                    "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
                                    "W", "X", "Y", "Z"};
    private String[] nextLetter  = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l",
                                    "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
                                    "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                                    "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
                                    "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    private Hashtable argCount = new Hashtable();


    // Class Methods ---------------------------------------------------------


    // Instance Methods ------------------------------------------------------
    /** Ctor. */
    public OverloadNameMaker() {}

    /** Return the next unique name for this namespace. */
    protected String getNextName(String descriptor) throws Exception
    {
        // Check for arg-list in hashtable
        String argList = getArgList(descriptor);
        Integer intCount = (Integer)argCount.get(argList);
        int theCount = 0;
        if (intCount == null)
        {
            argCount.put(argList, new Integer(theCount));
        }
        else
        {
            theCount = intCount.intValue() + 1;
            argCount.remove(argList);
            argCount.put(argList, new Integer(theCount));
        }
        return getName(theCount);
    }

    // Extract the arg-list from a descriptor
    private String getArgList(String descriptor) throws Exception
    {
        int pos = descriptor.indexOf(')');
        return descriptor.substring(1, pos);
    }

    // Generate another unique name
    private String getName(int index) throws Exception
    {
        String name = null;

        // Check if we are in the single letter part of the namespace
        if (index < firstLetter.length)
        {
            name = firstLetter[index];
        }
        else
        {
            // We are in the >=2 letter part of namespace (need to check for
            // namespace collisions with the keyword list here)
            index -= firstLetter.length;
            int nextLetters = 1;
            int subspaceSize = nextLetter.length;
            while (index >= firstLetter.length * subspaceSize)
            {
                index -= firstLetter.length * subspaceSize;
                nextLetters++;
                subspaceSize *= nextLetter.length;
            }

            // Pull out the name
            StringBuffer sb = new StringBuffer(firstLetter[index / subspaceSize]);
            while (subspaceSize != 1)
            {
                index %= subspaceSize;
                subspaceSize /= nextLetter.length;
                sb.append(nextLetter[index / subspaceSize]);
            }
            name = sb.toString();
        }
        return name;
    }
}

