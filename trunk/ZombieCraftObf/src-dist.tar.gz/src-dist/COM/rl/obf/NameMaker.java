/* ===========================================================================
 * $RCSfile: NameMaker.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf;

import java.io.*;
import java.util.*;

/**
 * Base class for name generators for a given namespace.
 * The base class gathers statistics for name mappings.
 *
 * @author      Mark Welsh
 */
abstract public class NameMaker
{
    // Fields ----------------------------------------------------------------
    protected static Hashtable frequency = new Hashtable(); // Used for logging frequency of generated names


    // Class Methods ---------------------------------------------------------
    /** Get an enumeration of distinct obfuscated names for all namespaces. */
    public static Enumeration getNames() 
    {
        return frequency.keys();
    }

    /** Get an enumeration of use count for distinct obfuscated names for all namespaces. */
    public static Enumeration getUseCounts() 
    {
        return frequency.elements();
    }


    // Instance Methods ------------------------------------------------------
    /** Return the next unique name for this namespace, differing only for identical arg-lists. */
    public String nextName(String descriptor) throws Exception
    {
        // Log the name usage globally across all namespaces
        String name = getNextName(descriptor);
        Integer intCount = (Integer)frequency.get(name);
        if (intCount == null)
        {
            frequency.put(name, new Integer(0));
        }
        else
        {
            frequency.remove(name);
            frequency.put(name, new Integer(intCount.intValue() + 1));
        }
        return name;
    }

    /** Return the next unique name for this namespace, differing only for identical arg-lists. */
    abstract protected String getNextName(String descriptor) throws Exception;
}
