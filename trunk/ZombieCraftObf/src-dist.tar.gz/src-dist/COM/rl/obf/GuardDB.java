/* ===========================================================================
 * $RCSfile: GuardDB.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf;

import java.io.*;
import java.util.*;
import java.util.zip.*;
import java.security.*;
import COM.rl.obf.classfile.*;
import COM.rl.util.*;
import COM.rl.util.rfc822.*;

/**
 * Classfile database for obfuscation.
 *
 * @author      Mark Welsh
 */
public class GuardDB implements ClassConstants
{
    // Constants -------------------------------------------------------------
    private static final String STREAM_NAME_MANIFEST = "META-INF/MANIFEST.MF";
    private static final String MANIFEST_VERSION_TAG = "Manifest-Version";
    private static final String MANIFEST_VERSION_VALUE = "1.0";
    private static final String MANIFEST_NAME_TAG = "Name";
    private static final String MANIFEST_DIGESTALG_TAG = "Digest-Algorithms";
    private static final String CLASS_EXT = ".class";
    private static final String SIGNATURE_PREFIX = "META-INF/";
    private static final String SIGNATURE_EXT = ".SF";
    private static final String LOG_MEMORY_USED = "# Memory in use after class data structure built: ";
    private static final String LOG_MEMORY_TOTAL = "# Total memory available                        : ";
    private static final String LOG_MEMORY_BYTES = " bytes";
    private static final String WARNING_SCRIPT_ENTRY_ABSENT = "# WARNING - identifier from script file not found in JAR: ";
    private static final String ERROR_CORRUPT_CLASS = "# ERROR - corrupt class file: ";


    // Fields ----------------------------------------------------------------
    private ZipFile inJar;          // JAR file for obfuscation
    private SectionList oldManifest;   // MANIFEST.MF RFC822-style data from old Jar
    private SectionList newManifest;   // MANIFEST.MF RFC822-style data for new Jar
    private ClassTree classTree;    // Tree of packages, classes. methods, fields
    private boolean hasMap = false; // Has the mapping been generated already?
    private boolean enableMapClassString = false; // Remap strings in reflection?
    private boolean enableDummySourceFile = false; // Remap SourceFile attribute to text "SourceFile"?
    private boolean enableDigestSHA = false; // Produce SHA-1 manifest digests?
    private boolean enableDigestMD5 = false; // Produce MD5 manifest digests?


    // Class Methods ---------------------------------------------------------


    // Instance Methods ------------------------------------------------------
    /** A classfile database for obfuscation. */
    public GuardDB(File inFile) throws Exception
    {
        inJar = new ZipFile(inFile);
        parseManifest();
    }

    /** Close input JAR file and log-file at GC-time. */
    protected void finalize() throws Exception
    {
        close();
    }

    /**
     * Go through database marking certain entities for retention, while
     * maintaining polymorphic integrity.
     */
    public void retain(RgsEnum rgsEnum, PrintWriter log) throws Exception
    {

        // Build database if not already done, or if a mapping has already been generated
        if (classTree == null || hasMap)
        {
            hasMap = false;
            buildClassTree(log);
        }

        // Always retain native methods and their classes, using script entry:
        // .method;native ** * and_class
        classTree.retainMethod("**", "*", true, null, false, 
                               ClassConstants.ACC_NATIVE, 
                               ClassConstants.ACC_NATIVE);

        // Enumerate the entries in the RGS script
        while (rgsEnum.hasMoreEntries())
        {
            RgsEntry entry = rgsEnum.nextEntry();
            try
            {
                switch (entry.type)
                {
                case RgsEntry.TYPE_OPTION:
                    if (ClassConstants.OPTION_DigestSHA.equals(entry.name))
                    {
                        enableDigestSHA = true;
                    }
                    else if (ClassConstants.OPTION_DigestMD5.equals(entry.name))
                    {
                        enableDigestMD5 = true;
                    }
                    else if (ClassConstants.OPTION_MapClassString.equals(entry.name))
                    {
                        enableMapClassString = true;
                    }
                    else if (ClassConstants.OPTION_LineNumberDebug.equals(entry.name))
                    {
                        classTree.retainAttribute(ClassConstants.ATTR_LineNumberTable);
                        classTree.retainAttribute(ClassConstants.ATTR_SourceFile);
                        enableDummySourceFile = true;
                    }
                    else if (ClassConstants.OPTION_RuntimeAnnotations.equals(entry.name))
                    {
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeVisibleAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeVisibleParameterAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_AnnotationDefault);
                    }
                    else if (ClassConstants.OPTION_Annotations.equals(entry.name))
                    {
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeVisibleAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeInvisibleAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeVisibleParameterAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_RuntimeInvisibleParameterAnnotations);
                        classTree.retainAttribute(ClassConstants.ATTR_AnnotationDefault);
                    }
                    else if (ClassConstants.OPTION_Enumeration.equals(entry.name))
                    {
// .option Enumeration - translates into
// .class ** public extends java/lang/Enum
                        classTree.retainClass("**", true, false, 
                                              false, false, false,
                                              "java/lang/Enum", false,
                                              0, 0);
                    }
                    else if (ClassConstants.OPTION_Application.equals(entry.name))
                    {
// .option Application - translates into
// .method **/main ([Ljava/lang/String;)V and_class
                        classTree.retainMethod("**/main", 
                                               "([Ljava/lang/String;)V",
                                               true, null, false, 
                                               0, 0);
                    }
                    else if (ClassConstants.OPTION_Applet.equals(entry.name))
                    {
// .option Applet - translates into
// .class ** extends java/applet/Applet
                        classTree.retainClass("**", false, false, 
                                              false, false, false,
                                              "java/applet/Applet", false,
                                              0, 0);
                    }
                    else if (ClassConstants.OPTION_RMI.equals(entry.name))
                    {
// .option RMI - translates into
// .option Serializable (see below for details)
// .class ** protected extends java/rmi/Remote
// .class **_Stub
// .class **_Skel
                        classTree.retainClass
                            ("**", false, 
                             true, // protected
                             false, false, false,
                             "java/rmi/Remote", false,
                             0, 0);
                        classTree.retainClass
                            ("**_Stub", false, false, 
                             false, false, false,
                             null, false, 
                             0, 0);
                        classTree.retainClass
                            ("**_Skel", false, false, 
                             false, false, false,
                             null, false,
                             0, 0);
                    }
                    if (ClassConstants.OPTION_Serializable.equals(entry.name) ||
                        ClassConstants.OPTION_RMI.equals(entry.name))
                    {
// .option Serializable - translates into
// .method;private **/writeObject (Ljava/io/ObjectOutputStream;)V extends java/io/Serializable
// .method;private **/readObject (Ljava/io/ObjectInputStream;)V extends java/io/Serializable
// .method **/writeReplace ()Ljava/lang/Object; extends java/io/Serializable
// .method **/readResolve ()Ljava/lang/Object; extends java/io/Serializable
// .field;static;final **/serialVersionUID J extends java/io/Serializable
// .field;static;final **/serialPersistentFields [Ljava/io/ObjectStreamField; extends java/io/Serializable
// .class ** extends java/io/Serializable
// .field;!transient;!static ** * extends java/io/Serializable
                        classTree.retainMethod
                            ("**/writeObject", 
                             "(Ljava/io/ObjectOutputStream;)V",
                             false, "java/io/Serializable", false, 
                             ClassConstants.ACC_PRIVATE, 
                             ClassConstants.ACC_PRIVATE);
                        classTree.retainMethod
                            ("**/readObject", 
                             "(Ljava/io/ObjectInputStream;)V",
                             false, "java/io/Serializable", false,
                             ClassConstants.ACC_PRIVATE, 
                             ClassConstants.ACC_PRIVATE);
                        classTree.retainMethod
                            ("**/writeReplace", 
                             "()Ljava/lang/Object;",
                             false, "java/io/Serializable", false, 
                             0, 0);
                        classTree.retainMethod
                            ("**/readResolve", 
                             "()Ljava/lang/Object;",
                             false, "java/io/Serializable", false,
                             0, 0);
                        classTree.retainField
                            ("**/serialVersionUID", 
                             "J", 
                             false, "java/io/Serializable", false, 
                             ClassConstants.ACC_STATIC | 
                             ClassConstants.ACC_FINAL, 
                             ClassConstants.ACC_STATIC | 
                             ClassConstants.ACC_FINAL);
                        classTree.retainField
                            ("**/serialPersistentFields", 
                             "[Ljava/io/ObjectStreamField;",
                             false, "java/io/Serializable", false, 
                             ClassConstants.ACC_PRIVATE | 
                             ClassConstants.ACC_STATIC | 
                             ClassConstants.ACC_FINAL, 
                             ClassConstants.ACC_PRIVATE | 
                             ClassConstants.ACC_STATIC | 
                             ClassConstants.ACC_FINAL);
                        classTree.retainClass
                            ("**", false, false, 
                             false, false, false,
                             "java/io/Serializable", false,
                             0, 0);
                        classTree.retainField
                            ("**", "*", 
                             false, "java/io/Serializable", false,
                             ClassConstants.ACC_TRANSIENT | 
                             ClassConstants.ACC_STATIC,
                             0);
                    }
                    break;

                case RgsEntry.TYPE_ATTR:
                    classTree.retainAttribute(entry.name);
                    break;

                case RgsEntry.TYPE_CLASS:
                case RgsEntry.TYPE_NOT_CLASS:
                    classTree.retainClass(entry.name, 
                                          entry.retainToPublic, 
                                          entry.retainToProtected, 
                                          entry.retainPubProtOnly,
                                          entry.retainFieldsOnly, 
                                          entry.retainMethodsOnly,
                                          entry.extendsName,
                                          entry.type == entry.TYPE_NOT_CLASS,
                                          entry.accessMask,
                                          entry.accessSetting);
                    break;

                case RgsEntry.TYPE_METHOD:
                case RgsEntry.TYPE_NOT_METHOD:
                    classTree.retainMethod(entry.name, entry.descriptor,
                                           entry.retainAndClass,
                                           entry.extendsName,
                                           entry.type == entry.TYPE_NOT_METHOD,
                                           entry.accessMask,
                                           entry.accessSetting);
                    break;

                case RgsEntry.TYPE_FIELD:
                case RgsEntry.TYPE_NOT_FIELD:
                    classTree.retainField(entry.name, entry.descriptor,
                                          entry.retainAndClass,
                                          entry.extendsName,
                                          entry.type == entry.TYPE_NOT_FIELD,
                                          entry.accessMask,
                                          entry.accessSetting);
                    break;

                case RgsEntry.TYPE_PACKAGE_MAP:
                    classTree.retainPackageMap(entry.name, entry.obfName);
                    break;

                case RgsEntry.TYPE_CLASS_MAP:
                    classTree.retainClassMap(entry.name, entry.obfName);
                    break;

                case RgsEntry.TYPE_METHOD_MAP:
                    classTree.retainMethodMap(entry.name, entry.descriptor, 
                                              entry.obfName);
                    break;

                case RgsEntry.TYPE_FIELD_MAP:
                    classTree.retainFieldMap(entry.name, entry.obfName);
                    break;

                default:
                    throw new Exception("Illegal type received from the .rgs script");
                }
            }
            catch (Exception e)
            {
                log.println(WARNING_SCRIPT_ENTRY_ABSENT + entry.name);
            }
        }
    }

    /** Remap each class based on the remap database, and remove attributes. */
    public void remapTo(File out, PrintWriter log) throws Exception
    {
        // Build database if not already done
        if (classTree == null)
        {
            buildClassTree(log);
        }

        // Generate map table if not already done
        if (!hasMap)
        {
            createMap(log);
        }

        // Go through the input Jar, removing attributes and remapping the Constant Pool
        // for each class file. Other files are copied through unchanged, except for manifest
        // and any signature files - these are deleted and the manifest is regenerated.
        Enumeration entries = inJar.entries();
        ZipOutputStream outJar = null;
        try
        {
            outJar = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)));
            //outJar.setComment(Version.getJarComment());
            while (entries.hasMoreElements())
            {
                // Get the next entry from the input Jar
                ZipEntry inEntry = (ZipEntry)entries.nextElement();

                // Ignore directories
                if (inEntry.isDirectory())
                {
                    continue;
                }
                
                // Open the entry and prepare to process it
                DataInputStream inStream = null;
                try
                {
                    inStream = new DataInputStream(
                        new BufferedInputStream(
                            inJar.getInputStream(inEntry)));
                    String inName = inEntry.getName();
                    if (inName.length() > CLASS_EXT.length() &&
                        inName.substring(inName.length() - CLASS_EXT.length(), inName.length()).equals(CLASS_EXT))
                    {
                        // Write the obfuscated version of the class to the output Jar
                        ClassFile cf = ClassFile.create(inStream);
                        cf.remap(classTree, log, enableMapClassString, enableDummySourceFile);
                        ZipEntry outEntry = new ZipEntry(cf.getName() + CLASS_EXT);
                        outJar.putNextEntry(outEntry);
                        
                        // Create an OutputStream piped through a number of digest generators for the manifest
                        MessageDigest shaDigest = null;
                        MessageDigest md5Digest = null;
                        OutputStream outputStream = outJar;
                        if (enableDigestSHA)
                        {
                            shaDigest = MessageDigest.getInstance("SHA-1");
                            outputStream = 
                                new DigestOutputStream(outputStream, 
                                                       shaDigest);
                        }
                        if (enableDigestMD5)
                        {
                            md5Digest = MessageDigest.getInstance("MD5");
                            outputStream = 
                                new DigestOutputStream(outputStream, 
                                                       md5Digest);
                        }
                        DataOutputStream dataOutputStream = 
                            new DataOutputStream(outputStream);
                        
                        // Dump the classfile, while creating the digests
                        cf.write(dataOutputStream);
                        dataOutputStream.flush();
                        outJar.closeEntry();
                    
                        // Now update the manifest entry for the class with new name and new digests
                        MessageDigest[] digests = {shaDigest, md5Digest};
                        updateManifest(inName, cf.getName() + CLASS_EXT, 
                                       digests);
                    }
                    else if (STREAM_NAME_MANIFEST.equals(inName.toUpperCase()) ||
                             (inName.length() > (SIGNATURE_PREFIX.length() + 1 + SIGNATURE_EXT.length()) &&
                              inName.indexOf(SIGNATURE_PREFIX) != -1 && 
                              inName.substring(inName.length() - SIGNATURE_EXT.length(), inName.length()).equals(SIGNATURE_EXT)))
                    {
                        // Don't pass through the manifest or signature files
                        continue;
                    }
                    else
                    {
                        // Copy the non-class entry through unchanged
                        long size = inEntry.getSize();
                        if (size != -1)
                        {
                            byte[] bytes = new byte[(int)size];
                            inStream.readFully(bytes);
                            String outName = classTree.getOutName(inName);
                            ZipEntry outEntry = new ZipEntry(outName);
                            outJar.putNextEntry(outEntry);
                            
                            // Create an OutputStream piped through a number of digest generators for the manifest
                            MessageDigest shaDigest = null;
                            MessageDigest md5Digest = null;
                            OutputStream outputStream = outJar;
                            if (enableDigestSHA)
                            {
                                shaDigest = MessageDigest.getInstance("SHA-1");
                                outputStream = 
                                    new DigestOutputStream(outputStream, 
                                                           shaDigest);
                            }
                            if (enableDigestMD5)
                            {
                                md5Digest = MessageDigest.getInstance("MD5");
                                outputStream = 
                                    new DigestOutputStream(outputStream, 
                                                           md5Digest);
                            }
                            DataOutputStream dataOutputStream = 
                                new DataOutputStream(outputStream);

                            // Dump the data, while creating the digests
                            dataOutputStream.write(bytes, 0, bytes.length);
                            dataOutputStream.flush();
                            outJar.closeEntry();
                    
                            // Now update the manifest entry for the entry with new name and new digests
                            MessageDigest[] digests = {shaDigest, md5Digest};
                            updateManifest(inName, outName, digests);
                        }
                    }
                }
                finally
                {
                    if (inStream != null)
                    {
                        inStream.close();
                    }
                }
            }
            
            // Finally, write the new manifest file
            ZipEntry outEntry = new ZipEntry(STREAM_NAME_MANIFEST);
            outJar.putNextEntry(outEntry);
            PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outJar)));
            newManifest.writeString(writer);
            writer.flush();
            outJar.closeEntry();
        }
        finally
        {
            if (outJar != null)
            {
                outJar.close();
            }
        }
    }

    /** Close input JAR file. */
    public void close() throws Exception {
        if (inJar != null) 
        {
            inJar.close();
            inJar = null;
        }
    }

    // Parse the RFC822-style MANIFEST.MF file
    private void parseManifest() throws Exception
    {
        // The manifest file is the first in the jar and is called
        // (case insensitively) 'MANIFEST.MF'
        oldManifest = new SectionList();
        Enumeration entries = inJar.entries();
        while (entries.hasMoreElements()) 
        {
            // Get the first entry only from the input Jar
            ZipEntry inEntry = (ZipEntry)entries.nextElement();
            String name = inEntry.getName();
            if (STREAM_NAME_MANIFEST.equals(name.toUpperCase())) 
            {
                oldManifest.parse(inJar.getInputStream(inEntry));
                break;
            }
        }

        // Create a fresh manifest, with a version header
        newManifest = new SectionList();
        Section version = oldManifest.find(MANIFEST_VERSION_TAG, 
                                           MANIFEST_VERSION_VALUE);
        if (version == null) 
        {
            version = new Section();
            version.add(MANIFEST_VERSION_TAG, MANIFEST_VERSION_VALUE);
        }
        newManifest.add(version);

        // copy through all the none-filename sections, apart from the version
        for (Enumeration enm = oldManifest.elements(); 
             enm.hasMoreElements(); ) 
        {
            Section section = (Section)enm.nextElement();
            if (section != null && section != version) 
            {
                Header name = section.findTag(MANIFEST_NAME_TAG);
                if (name == null) 
                {
                    newManifest.add(section);
                } 
                else 
                {
                    String value = name.getValue();
                    if (value.length() > 0 && 
                        value.charAt(value.length() - 1) == '/') 
                    {
                        newManifest.add(section);
                    }
                }
            }
        }
    }

    // Update an entry in the manifest file
    private void updateManifest(String inName, String outName, 
                                MessageDigest[] digests)
    {
        // Create fresh section for entry, and enter "Name" header
        Section newSection = new Section();
        newSection.add(MANIFEST_NAME_TAG, outName);

        // Check for section in old manifest, and copy over non-"Name", non-digest entries
        Section oldSection = oldManifest.find(MANIFEST_NAME_TAG, inName);
        if (oldSection != null)
        {
            for (Enumeration enm = oldSection.elements(); enm.hasMoreElements(); )
            {
                Header header = (Header)enm.nextElement();
                if (!header.getTag().equals(MANIFEST_NAME_TAG) &&
                    header.getTag().indexOf("Digest") == -1)
                {
                    newSection.add(header);
                }
            }
        }

        // Create fresh digest entries in the new section
        if (digests != null && digests.length > 0)
        {
            // Digest-Algorithms header
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < digests.length; i++)
            {
                if (digests[i] != null)
                {
                    sb.append(digests[i].getAlgorithm());
                    sb.append(" ");
                }
            }
            if (sb.length() > 0) 
            {
                newSection.add(MANIFEST_DIGESTALG_TAG, sb.toString());
            }

            // *-Digest headers
            for (int i = 0; i < digests.length; i++)
            {
                if (digests[i] != null)
                {
                    newSection.add(digests[i].getAlgorithm() + "-Digest", 
                                   Tools.toBase64(digests[i].digest()));
                }
            }            
        }

        // Append the new section to the new manifest
        newManifest.add(newSection);
    }

    // Create a classfile database.
    private void buildClassTree(PrintWriter log) throws Exception
    {
        // Go through the input Jar, adding each class file to the database
        classTree = new ClassTree();
        ClassFile.resetDangerHeader();
        Enumeration entries = inJar.entries();
        while (entries.hasMoreElements())
        {
            // Get the next entry from the input Jar
            ZipEntry inEntry = (ZipEntry)entries.nextElement();
            String name = inEntry.getName();
            if (name.length() > CLASS_EXT.length() &&
                name.substring(name.length() - CLASS_EXT.length(), name.length()).equals(CLASS_EXT))
            {
                // Create a full internal representation of the class file
                DataInputStream inStream = new DataInputStream(
                    new BufferedInputStream(
                        inJar.getInputStream(inEntry)));
                ClassFile cf = null;
                try
                {
                    cf = ClassFile.create(inStream);
                }
                catch (Exception e)
                {
                    log.println(ERROR_CORRUPT_CLASS + name + " (" + e.getMessage() + ")");
                }
                finally
                {
                    inStream.close();
                }

                // Check the classfile for references to 'dangerous' methods
                cf.logDangerousMethods(log);
                classTree.addClassFile(cf);
            }
        }
    }

    // Generate a mapping table for obfuscation.
    private void createMap(PrintWriter log) throws Exception
    {
        // Traverse the class tree, generating obfuscated names within
        // package and class namespaces
        classTree.generateNames();

        // Resolve the polymorphic dependencies of each class, generating
        // non-private method and field names for each namespace
        classTree.resolveClasses();

        // Signal that the namespace maps have been created
        hasMap = true;

        // Write the memory usage at this point to the log file
        Runtime rt = Runtime.getRuntime();
        rt.gc();
        log.println("#");
        log.println(LOG_MEMORY_USED + Long.toString(rt.totalMemory() - rt.freeMemory()) + LOG_MEMORY_BYTES);
        log.println(LOG_MEMORY_TOTAL + Long.toString(rt.totalMemory()) + LOG_MEMORY_BYTES);
        log.println("#");

        // Write the name frequency and name mapping table to the log file
        classTree.dump(log);
    }
}
