/* ===========================================================================
 * $RCSfile: MemberValuePairInfo.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf.classfile;

import java.io.*;
import java.util.*;

/**
 * Representation of an annotation's member-value-pair entry.
 *
 * @author      Mark Welsh
 */
public class MemberValuePairInfo
{
    // Constants -------------------------------------------------------------


    // Fields ----------------------------------------------------------------
    private int u2memberNameIndex;
    private MemberValueInfo value;


    // Class Methods ---------------------------------------------------------
    public static MemberValuePairInfo create(DataInput din) throws Exception
    {
        MemberValuePairInfo mvpi = new MemberValuePairInfo();
        mvpi.read(din);
        return mvpi;
    }


    // Instance Methods ------------------------------------------------------
    private MemberValuePairInfo() {}

    /** Return member name index into Constant Pool. */
    protected int getMemberNameIndex() {return u2memberNameIndex;}

    /** Check for Utf8 references to constant pool and mark them. */
    protected void markUtf8Refs(ConstantPool pool) throws Exception
    {
        pool.incRefCount(u2memberNameIndex);
        value.markUtf8Refs(pool);
    }

    private void read(DataInput din) throws Exception
    {
        u2memberNameIndex = din.readUnsignedShort();
        value = MemberValueInfo.create(din);
    }

    /** Export the representation to a DataOutput stream. */
    public void write(DataOutput dout) throws Exception
    {
        dout.writeShort(u2memberNameIndex);
        value.write(dout);
    }

    /** Do necessary name remapping. */
    protected void remap(ClassFile cf, NameMapper nm) throws Exception 
    { 
        value.remap(cf, nm);
    }

    /** Provide debugging dump of this object. */
    public void dump(PrintStream ps, ClassFile cf) throws Exception
    {
        ps.println("u2memberNameIndex : " + u2memberNameIndex + " " + cf.getUtf8(u2memberNameIndex));
        value.dump(ps, cf);
    }
}
