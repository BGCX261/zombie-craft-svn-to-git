/* ===========================================================================
 * $RCSfile: ParameterAnnotationsInfo.java,v $
 * ===========================================================================
 *
 * RetroGuard -- an obfuscation package for Java classfiles.
 *
 * Copyright (c) 1998-2005 Mark Welsh (markw@retrologic.com)
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * The author may be contacted at markw@retrologic.com 
 *
 */

package COM.rl.obf.classfile;

import java.io.*;
import java.util.*;

/**
 * Representation of an parameter annotations table entry.
 *
 * @author      Mark Welsh
 */
public class ParameterAnnotationsInfo
{
    // Constants -------------------------------------------------------------


    // Fields ----------------------------------------------------------------
    private int u2numAnnotations;
    private AnnotationInfo[] annotationTable;


    // Class Methods ---------------------------------------------------------
    public static ParameterAnnotationsInfo create(DataInput din) throws Exception
    {
        ParameterAnnotationsInfo pai = new ParameterAnnotationsInfo();
        pai.read(din);
        return pai;
    }


    // Instance Methods ------------------------------------------------------
    private ParameterAnnotationsInfo() {}

    /** Return the array of annotation table entries. */
    protected AnnotationInfo[] getAnnotationTable() throws Exception
    {
        return annotationTable;
    }

    /** Check for Utf8 references to constant pool and mark them. */
    protected void markUtf8Refs(ConstantPool pool) throws Exception
    {
        for (int i = 0; i < annotationTable.length; i++)
        {
            annotationTable[i].markUtf8Refs(pool);
        }
    }

    private void read(DataInput din) throws Exception
    {
        u2numAnnotations = din.readUnsignedShort();
        annotationTable = new AnnotationInfo[u2numAnnotations];
        for (int i = 0; i < u2numAnnotations; i++)
        {
            annotationTable[i] = AnnotationInfo.create(din);
        }
    }

    /** Export the representation to a DataOutput stream. */
    public void write(DataOutput dout) throws Exception
    {
        dout.writeShort(u2numAnnotations);
        for (int i = 0; i < u2numAnnotations; i++)
        {
            annotationTable[i].write(dout);
        }
    }

    /** Do necessary name remapping. */
    protected void remap(ClassFile cf, NameMapper nm) throws Exception 
    { 
        for (int i = 0; i < u2numAnnotations; i++)
        {
            annotationTable[i].remap(cf, nm);
        }
    }
}
